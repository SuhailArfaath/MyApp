#!/bin/bash
export Myhostname=`hostname`
echo "==========================================================="
echo "This script is running on ${Myhostname} ."
echo "==========================================================="