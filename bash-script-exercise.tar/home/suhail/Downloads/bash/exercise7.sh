#!/bin/bash
path=$1
if [ -f “$path” ]
  then
    echo “$path is a reguler path”
elif [ -d “$path” ]
  then
    echo “$path is a directory”
else
   echo “$path is another type of path”
fi
ls -l $path