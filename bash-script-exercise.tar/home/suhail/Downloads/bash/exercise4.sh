#!/bin/bash
echo "Exercise: 4"
echo "==========================================================="
Folder=/etc/
if test -d "$Folder" 
then
    echo "Folder available"
    if test -e /etc/shadow
    then
        echo "Shadow passwords are enabled."
        if test -w
        then
            echo "You have permissions to edit /etc/shadow."
        else
            echo "You do NOT have permissions to edit /etc/shadow."
        fi
    fi
fi
echo "==========================================================="