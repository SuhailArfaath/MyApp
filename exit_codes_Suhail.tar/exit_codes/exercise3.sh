#! /bin/bash

cat /etc/
exit_code=$?

echo "Exit status is ${exit_code}"

if [ ${exit_code} -eq "0" ]
then 
	echo "Command succeeded"
else
	echo "Command failed"
	exit 1
fi

