if [ -f $1 ]
then
	echo "$1 : regular file. Exiting with 0."
	exit 0
elif [ -d $1 ] 
then
	echo "$1 : directory. Exiting with 1."
	exit 1
else
	echo "$1 : other file. Exiting with 2"
	exit 2
fi