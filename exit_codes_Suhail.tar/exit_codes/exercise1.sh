#!/bin/bash
cd ..
Status=$?
echo "Exit code is : ${Status}"